# image-filter
a simple script to apply image filters in pytohn
